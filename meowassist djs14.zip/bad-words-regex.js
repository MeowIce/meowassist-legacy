module.exports =
	/cặc|lồn|địt|buồi|cứt|vãi|đít|đụ|đéo|đệch|má|mày|mòe|shit|fuck|penis|dick|d1ck|nigga|n1gga|sex|segg|seggs|chịch|chich|trash|asshole|ass|motherfucker|fucker|sucker|sucks|suck/gi;
